﻿using Core.DataAcess;
using Entity.Concrete;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataAcess.Abstract
{
   public interface ICategoryDal:IRepository<Category>
    {
    }
}
